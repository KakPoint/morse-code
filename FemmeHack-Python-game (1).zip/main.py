#Game: morse code learner
#morse to english + english to morse


selectionSec = 0
import random
exit = False
englishChar = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
morseChar = ['.-', '-..', '-.-.', '-..', '.', '..-.', '--.', '....', '..', '.---', '-.-', '.-..', '--', '-.', '---' , '.--.' , '--.-' , '.-.', '...', '-', '..-', '...-', '.--', '-..-', '-.--', '--..']
wrong = []


#Game for morse to english alphabet (1-1)
def morseToEng ():
  morseChar = ['.-', '-...', '-.-.', '-..', '.', '..-.', '--.', '....', '..', '.---', '-.-', '.-..', '--', '-.', '---' , '.--.' , '--.-' , '.-.', '...', '-', '..-', '...-', '.--', '-..-', '-.--', '--..']
  englishChar = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
  wrong = []
  score = 0
  for i in range(0,26):
    randNum = random.randint(0,len(morseChar)-1)
    print("What is " + str(morseChar[randNum]) + " in English?")
    answer = input("Enter the correct answer: ")

    if (answer == englishChar[randNum]):
      print("")
      print("Correct!")
      print("")
      score = score + 1
      morseChar.remove(morseChar[randNum])
      englishChar.remove(englishChar[randNum])
    else:
      print("")
      print("Incorrect")
      print("Answer is: " + str(englishChar[randNum]))
      print("")
      wrong.append(englishChar[randNum])
      morseChar.remove(morseChar[randNum])
      englishChar.remove(englishChar[randNum])
  print ("You got " + str(score) + "/26 correct!")
  if (score != 26):
    print("You messed up on these letters: " + str(wrong))
  morseChar = ['.-', '-...', '-.-.', '-..', '.', '..-.', '--.', '....', '..', '.---', '-.-', '.-..', '--', '-.', '---' , '.--.' , '--.-' , '.-.', '...', '-', '..-', '...-', '.--', '-..-', '-.--', '--..']
  englishChar = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
  
  #End of Game Function happens
  print("Say: 'again' to play again, OR say: 'end' to go back to the main menu!")
  endGame = input('')
  if (endGame == 'again'):
    print("------------------------------------------")
    print("")
    print("")
    print("")
    morseToEng()
  elif (endGame == 'end'):
    print("------------------------------------------")
    print("")
    print("")
    print("")
    menu()
  else:
    print("------------------------------------------")
    print("")
    print("")
    print("")
    print("Invalid selection, going back to main menu")
    menu()

#Game for morse to english words (1-2)
def morseToEngW ():
  morseWords = ['..-. . -- -- .', '... .... .', '- .... . -.--', '.... .- -.-. -.-', '.--. . -. -.', '- . -.-. ....', '-.-. --- -.. .', '-.-- --- ..-', '.--. -.-- - .... --- -.', '.- .-. .', '- .... .', '..-. .-. .. . -. -..', '- . .- --', '..-. ..- -.']
  englishWords = ['femme','she','they','hack','penn','tech','code','you','python', 'are', 'the', 'friend','team','fun' ]
  wrong = []
  score = 0
  for i in range(0,14):
    randNum = random.randint(0,len(morseWords)-1)
    print("What is " + str(morseWords[randNum]) + " in English?")
    answer = input("Enter the correct answer: ")

    if (answer == englishWords[randNum]):
      print("")
      print("Correct!")
      print("")
      score = score + 1
      morseWords.remove(morseWords[randNum])
      englishWords.remove(englishWords[randNum])
    else:
      print("")
      print("Incorrect")
      print("Answer is: " + str(englishWords[randNum]))
      print("")
      wrong.append(englishWords[randNum])
      morseWords.remove(morseWords[randNum])
      englishWords.remove(englishWords[randNum])
  print ("You got " + str(score) + "/14 correct!")
  if (score != 14):
    print("You messed up on these words: " + str(wrong))
  
  
  #End of Game Function happens
  print("Say: 'again' to play again, OR say: 'end' to go back to the main menu!")
  endGame = input('')
  if (endGame == 'again'):
    print("------------------------------------------")
    print("")
    print("")
    print("")
    morseToEngW()
    
  elif (endGame == 'end'):
    print("------------------------------------------")
    print("")
    print("")
    print("")
    menu()

  else:
    print("------------------------------------------")
    print("")
    print("")
    print("")
    print("Invalid selection, going back to main menu")
    menu()

#English to Morse Alphabet game function
def engToMorse ():
  morseChar = ['.-', '-...', '-.-.', '-..', '.', '..-.', '--.', '....', '..', '.---', '-.-', '.-..', '--', '-.', '---' , '.--.' , '--.-' , '.-.', '...', '-', '..-', '...-', '.--', '-..-', '-.--', '--..']
  englishChar = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
  wrong = []
  score = 0
  for i in range(0,26):
    randNum = random.randint(0,len(morseChar)-1)
    print("What is " + str(englishChar[randNum]) + " in Morse?")
    answer = input("Enter the correct answer: ")

    if (answer == morseChar[randNum]):
      print("")
      print("Correct!")
      print("")
      score = score + 1
      morseChar.remove(morseChar[randNum])
      englishChar.remove(englishChar[randNum])
    else:
      print("")
      print("Incorrect")
      print("Answer is: " + str(morseChar[randNum]))
      print("")
      wrong.append(morseChar[randNum])
      morseChar.remove(morseChar[randNum])
      englishChar.remove(englishChar[randNum])
  print ("You got " + str(score) + "/26 correct!")
  if (score != 26):
    print("You messed up on these letters: " + str(wrong))
  morseChar = ['.-', '-...', '-.-.', '-..', '.', '..-.', '--.', '....', '..', '.---', '-.-', '.-..', '--', '-.', '---' , '.--.' , '--.-' , '.-.', '...', '-', '..-', '...-', '.--', '-..-', '-.--', '--..']
  englishChar = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
  
  #End of Game Function happens
  print("Say: 'again' to play again, OR say: 'end' to go back to the main menu!")
  endGame = input('')
  if (endGame == 'again'):
    print("------------------------------------------")
    print("")
    print("")
    print("")
    engToMorse()
  elif (endGame == 'end'):
    print("------------------------------------------")
    print("")
    print("")
    print("")
    menu()


  else:
    print("------------------------------------------")
    print("")
    print("")
    print("")
    print("Invalid selection, going back to main menu")
    menu()
    
#English to Morse word game
def engToMorseW ():
  morseWords = ['..-. . -- -- .', '... .... .', '- .... . -.--', '.... .- -.-. -.-', '.--. . -. -.', '- . -.-. ....', '-.-. --- -.. .', '-.-- --- ..-', '.--. -.-- - .... --- -.', '.- .-. .', '- .... .', '..-. .-. .. . -. -..', '- . .- --', '..-. ..- -.']
  englishWords = ['femme','she','they','hack','penn','tech','code','you','python', 'are', 'the', 'friend','team','fun' ]
  wrong = []
  score = 0
  for i in range(0,14):
    randNum = random.randint(0,len(morseWords)-1)
    print("What is " + str(englishWords[randNum]) + " in Morse?")
    answer = input("Enter the correct answer: ")

    if (answer == morseWords[randNum]):
      print("")
      print("Correct!")
      print("")
      score = score + 1
      morseWords.remove(morseWords[randNum])
      englishWords.remove(englishWords[randNum])
    else:
      print("")
      print("Incorrect")
      print("Answer is: " + str(morseWords[randNum]))
      print("")
      wrong.append(morseWords[randNum])
      morseWords.remove(morseWords[randNum])
      englishWords.remove(englishWords[randNum])
  print ("You got " + str(score) + "/14 correct!")
  if (score != 14):
    print("You messed up on these words: " + str(wrong))
  
  
  #End of Game Function happens
  print("Say: 'again' to play again, OR say: 'end' to go back to the main menu!")
  endGame = input('')
  if (endGame == 'again'):
    print("------------------------------------------")
    print("")
    print("")
    print("")
    morseToEngW()
    
  elif (endGame == 'end'):
    print("------------------------------------------")
    print("")
    print("")
    print("")
    menu()

  else:
    print("------------------------------------------")
    print("")
    print("")
    print("")
    print("Invalid selection, going back to main menu")
    menu()

#Menu fucntion
def menu():

  print("                 ~MAIN MENU~")
  print("-_-_-_---------------------------------_-_-_-")
  print("   |    [1] Learn Morse to English       | ")
  print("   +    [2] Learn English to Morse       + ")
  print("   |    [3] EXIT                         | ")
  print("-_-_-_---------------------------------_-_-_-")
  print(' ')
  print('         ' ,end='')
  selectionMain = int(input('Please make a selection: '))






  #Main selction: Morse to English: 1  
  if (selectionMain == 1):
    print("------------------------------------------")
    print("")
    print("")
    print("")
    print("[1] Learn the Alphabet")
    print("[2] Learn Words")
    print("[3] Go Back to Main Menu")
    selectionSec = (int(input('Please make a selection: ')))

#Sec selction: Morse to English: Learn Alphabet
    if (selectionSec == 1):
      print("------------------------------------------")
      print("")
      print("")
      print("")
      
      #prints out morse key
      for i in range(26):
        print(englishChar[i] + '   ', end='')
        print(morseChar[i])
        print()
      #Prompts for user to start
      print("------------------------------------------")
      print("")
      print("Here is the alphabet, hit '1' when you are ready to play! Or hit another number key if you would like to exit.")
      playGame = int(input(''))
      
      #plays/starts game
      if (playGame == 1):
        print("------------------------------------------")
        print("")
        print("Only use the key if you need to!")
        print("------------------------------------------")
        print("")
        morseToEng()

      #Exits  
      else:
        print("------------------------------------------")
        print("")
        print("")
        print("")
        menu()
      


#Sec selction: Morse to English: Learn Words 
    elif(selectionSec == 2):
      print("------------------------------------------")
      print("")
      print("")
      print("")
      #prints out morse key
      for i in range(26):
        print(englishChar[i] + '   ', end='')
        print(morseChar[i])
        print()
      print("------------------------------------------")
      print('Here is the Key incase you need it!')  
      print("------------------------------------------")
      print ("")
      print("How to read Morse")
      print("Each letter is a certain order of '-' and/or '.'")
      print("Each morse letter will have a space between it, when writing the morse in english, you will not put a space between the letters.")
      print ("Ex: .... . .-.. .-.. --- ")
      print ('        Hello')
      print("------------------------------------------")
      
      #Prompts for user to start
      print("------------------------------------------")
      print("")
      print("Here is the alphabet, hit '1' when you are ready to play! Or hit another number key if you would like to exit.")
      playGame = int(input(''))
      
      #plays/starts game
      if (playGame == 1):
        print("------------------------------------------")
        print("")
        print("Only use the key if you need to!")
        print("------------------------------------------")
        print("")
        morseToEngW()

#Sec selction: Morse to English: Back to Main      
      else:
        print("------------------------------------------")
        print("")
        print("")
        print("")
        menu()
    else: 
      print("------------------------------------------")
      print("")
      print("")
      print("")
      menu()



  #Main selection: English to Morse: 2
  elif (selectionMain == 2):
    print("------------------------------------------")
    print("")
    print("")
    print("")
    print("[1] Learn the Alphabet")
    print("[2] Learn Words")
    print("[3] Go Back to Main Menu")
    selectionSec = (int(input('Please make a selection: ')))

    #Eng to Morse Alph
    if (selectionSec == 1):
      print("------------------------------------------")
      print("")
      print("")
      print("")
      #prints out morse key
      for i in range(26):
        print(englishChar[i] + '   ', end='')
        print(morseChar[i])
        print()
      #Prompts for user to start
      print("------------------------------------------")
      print("")
      print("Here is the alphabet, hit '1' when you are ready to play! Or hit another number key if you would like to exit.")

      playGame = int(input(''))
      
      #plays/starts game
      if (playGame == 1):
        print("------------------------------------------")
        print("")
        print("Only use the key if you need to!")
        print("------------------------------------------")
        print("")
        engToMorse()
      else: 
        print("------------------------------------------")
        print("")
        print("")
        print("")
        menu()
      
    #eng to morse words
    elif(selectionSec == 2):
      print("------------------------------------------")
      print("")
      print("")
      print("")
      print("------------------------------------------")
      print("")
      print("")
      print("")
      #prints out morse key
      for i in range(26):
        print(englishChar[i] + '   ', end='')
        print(morseChar[i])
        print()
      print("------------------------------------------")
      print('Here is the Key incase you need it!')  
      print("------------------------------------------")
      print ("")
      print("How to type Morse")
      print("Each letter is a certain order of '-' and/or '.'")
      print("Each morse letter should have a space between it, when writing the english in morse, remember to put the spaces!")
      print ("Ex: .... . .-.. .-.. --- ")
      print ('        Hello')
      print("------------------------------------------")
      
      #Prompts for user to start
      print("------------------------------------------")
      print("")
      print("Here is the alphabet, hit '1' when you are ready to play! Or hit another number key if you would like to exit.")
      playGame = int(input(''))
      
      #plays/starts game
      if (playGame == 1):
        print("------------------------------------------")
        print("")
        print("Only use the key if you need to!")
        print("------------------------------------------")
        print("")
        engToMorseW()

      else:
        print("------------------------------------------")
        print("")
        print("")
        print("")
        menu()
    else:
      print("------------------------------------------")
      print("")
      print("")
      print("")
      menu()

  #Main selection: Exit: other (3)
  else:
     print("------------------------------------------")
     print('Exited')
     while (exit == False):
       break
     print("------------------------------------------")

menu()